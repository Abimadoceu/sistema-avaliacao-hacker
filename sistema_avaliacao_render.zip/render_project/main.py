import os
import sys
# DON'T CHANGE THIS LINE
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, render_template, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import secrets

# Configuração da aplicação para Render
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(16))

# Configuração do banco - usar PostgreSQL no Render se disponível, senão SQLite
database_url = os.environ.get('DATABASE_URL')
if database_url:
    # Corrigir URL do PostgreSQL se necessário
    if database_url.startswith('postgres://'):
        database_url = database_url.replace('postgres://', 'postgresql://', 1)
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
else:
    # SQLite para desenvolvimento local
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///avaliacao.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Importar modelos e inicializar db
from models.models import db, CodigoAcesso, Funcionario, Avaliacao, Competencia

# Inicializar extensões
db.init_app(app)
CORS(app)

# Importar rotas
from routes.codigo_auth import codigo_auth_bp
from routes.avaliacao_codigo import avaliacao_codigo_bp
from routes.relatorios import relatorios_bp

# Registrar blueprints
app.register_blueprint(codigo_auth_bp, url_prefix='/api/auth')
app.register_blueprint(avaliacao_codigo_bp, url_prefix='/api')
app.register_blueprint(relatorios_bp, url_prefix='/api/relatorios')

# Rota para servir o frontend
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

def init_database():
    """Inicializar banco de dados com dados padrão"""
    try:
        print("🚀 Iniciando criação do banco de dados...")
        db.create_all()
        print("✅ Tabelas criadas com sucesso!")
        
        # Verificar se já existem códigos
        if CodigoAcesso.query.count() == 0:
            print("🔑 Criando códigos de acesso...")
            
            # Criar 3 gestores
            gestores_data = [
                ('GESTOR01', 'Gestor Principal', 'senha123'),
                ('GESTOR02', 'Gestor Operacional', 'senha456'),
                ('GESTOR03', 'Gestor de RH', 'senha789')
            ]
            
            for codigo, nome, senha in gestores_data:
                gestor = CodigoAcesso(
                    codigo=codigo,
                    nome_usuario=nome,
                    tipo='gestor',
                    ativo=True
                )
                gestor.definir_senha(senha)
                db.session.add(gestor)
                print(f"👨‍💼 Gestor {codigo} criado")
            
            # Criar 40 avaliadores
            for i in range(1, 41):
                codigo = f'AVAL{i:03d}'
                nome = f'Avaliador {i:02d}'
                avaliador = CodigoAcesso(
                    codigo=codigo,
                    nome_usuario=nome,
                    tipo='avaliador',
                    senha=None,
                    ativo=True
                )
                db.session.add(avaliador)
            
            db.session.commit()
            print("✅ Códigos de acesso criados com sucesso!")
        else:
            print("ℹ️ Códigos de acesso já existem no banco")
        
        # Verificar se já existem competências
        if Competencia.query.count() == 0:
            print("📋 Criando competências...")
            competencias = [
                Competencia(nome='Pontualidade e Disciplina', descricao='Cumprimento de horários e regras da empresa'),
                Competencia(nome='Iniciativa e Proatividade', descricao='Capacidade de agir sem supervisão constante'),
                Competencia(nome='Produtividade e Eficiência', descricao='Cumprimento de metas e otimização de processos'),
                Competencia(nome='Foco no Resultado', descricao='Orientação para objetivos e persistência'),
                Competencia(nome='Cooperação e Trabalho em Equipe', descricao='Colaboração efetiva com colegas'),
                Competencia(nome='Autorresponsabilidade', descricao='Responsabilidade pessoal e autonomia'),
                Competencia(nome='Dinamismo e Adaptabilidade', descricao='Flexibilidade e energia para mudanças'),
                Competencia(nome='Liderança e Influência', descricao='Capacidade de liderar e influenciar positivamente'),
                Competencia(nome='Criatividade e Inovação', descricao='Pensamento inovador e busca por melhorias'),
                Competencia(nome='Conhecimento Técnico e Qualidade', descricao='Competência técnica e padrões de qualidade')
            ]
            
            for comp in competencias:
                db.session.add(comp)
            
            db.session.commit()
            print("✅ Competências criadas com sucesso!")
        else:
            print("ℹ️ Competências já existem no banco")
            
        print("🎉 Inicialização do banco de dados concluída!")
        
    except Exception as e:
        print(f"❌ Erro na inicialização do banco: {e}")
        import traceback
        traceback.print_exc()

# Inicializar banco automaticamente quando o app for criado
with app.app_context():
    init_database()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

