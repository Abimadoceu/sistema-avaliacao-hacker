# Sistema de Avaliação - Hacker Industrial

Sistema completo de avaliação de desempenho para a Hacker Industrial.

## 🚀 Deploy no Render

Este projeto está configurado para deploy automático no Render.

### Configurações de Deploy:
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `gunicorn main:app`
- **Environment**: Python 3

### Códigos de Acesso:

#### Gestores (com senha):
- GESTOR01 / senha123
- GESTOR02 / senha456  
- GESTOR03 / senha789

#### Avaliadores (sem senha):
- AVAL001 a AVAL040

## 📋 Funcionalidades

- ✅ Sistema de login com códigos
- ✅ Dashboard com métricas
- ✅ Gestão de funcionários
- ✅ Sistema de avaliações (10 competências)
- ✅ Relatórios completos
- ✅ Interface responsiva

## 🔧 Tecnologias

- Flask 3.0.0
- SQLAlchemy
- SQLite/PostgreSQL
- HTML/CSS/JavaScript
- Bootstrap

## 📱 Compatibilidade

- Desktop (Windows, Mac, Linux)
- Mobile (Android, iOS)
- Tablets
- Todos os navegadores modernos

