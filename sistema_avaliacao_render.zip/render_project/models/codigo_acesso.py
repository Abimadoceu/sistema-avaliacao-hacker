from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import secrets
import string

db = SQLAlchemy()

class CodigoAcesso(db.Model):
    __tablename__ = 'codigos_acesso'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(20), unique=True, nullable=False)
    nome_usuario = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(20), nullable=False)  # 'admin' ou 'avaliador'
    ativo = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime)
    
    # Relacionamentos
    funcionarios_cadastrados = db.relationship('Funcionario', backref='cadastrado_por_codigo', lazy=True, foreign_keys='Funcionario.cadastrado_por_codigo')
    avaliacoes_realizadas = db.relationship('Avaliacao', backref='avaliador_codigo', lazy=True, foreign_keys='Avaliacao.avaliador_codigo')
    
    def is_admin(self):
        """Verifica se o código é de administrador"""
        return self.tipo == 'admin'
    
    def can_access_funcionario(self, funcionario):
        """Verifica se o código pode acessar dados de um funcionário"""
        if self.is_admin():
            return True
        return funcionario.cadastrado_por_codigo == self.codigo
    
    def can_access_avaliacao(self, avaliacao):
        """Verifica se o código pode acessar uma avaliação"""
        if self.is_admin():
            return True
        # Pode acessar se foi quem fez a avaliação OU se cadastrou o funcionário
        return (avaliacao.avaliador_codigo == self.codigo or 
                avaliacao.funcionario.cadastrado_por_codigo == self.codigo)
    
    def update_last_used(self):
        """Atualiza último uso do código"""
        self.last_used = datetime.utcnow()
        db.session.commit()
    
    def to_dict(self):
        return {
            'id': self.id,
            'codigo': self.codigo,
            'nome_usuario': self.nome_usuario,
            'tipo': self.tipo,
            'ativo': self.ativo,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_used': self.last_used.isoformat() if self.last_used else None
        }

def generate_codigo():
    """Gera um código de acesso único"""
    while True:
        # Gera código de 8 caracteres (letras maiúsculas e números)
        codigo = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
        
        # Verifica se o código já existe
        if not CodigoAcesso.query.filter_by(codigo=codigo).first():
            return codigo

def create_admin_codes():
    """Cria códigos de administrador padrão se não existirem"""
    admin_codes = [
        {'codigo': 'ADMIN001', 'nome_usuario': 'Administrador Principal'},
        {'codigo': 'MASTER01', 'nome_usuario': 'Administrador Master'}
    ]
    
    created_codes = []
    for code_data in admin_codes:
        existing = CodigoAcesso.query.filter_by(codigo=code_data['codigo']).first()
        if not existing:
            codigo = CodigoAcesso(
                codigo=code_data['codigo'],
                nome_usuario=code_data['nome_usuario'],
                tipo='admin'
            )
            db.session.add(codigo)
            created_codes.append(code_data['codigo'])
    
    # Criar alguns códigos de avaliador de exemplo
    avaliador_codes = [
        {'codigo': 'AVAL001', 'nome_usuario': 'Avaliador 1'},
        {'codigo': 'AVAL002', 'nome_usuario': 'Avaliador 2'},
        {'codigo': 'AVAL003', 'nome_usuario': 'Avaliador 3'}
    ]
    
    for code_data in avaliador_codes:
        existing = CodigoAcesso.query.filter_by(codigo=code_data['codigo']).first()
        if not existing:
            codigo = CodigoAcesso(
                codigo=code_data['codigo'],
                nome_usuario=code_data['nome_usuario'],
                tipo='avaliador'
            )
            db.session.add(codigo)
            created_codes.append(code_data['codigo'])
    
    if created_codes:
        db.session.commit()
        print(f"Códigos de acesso criados: {', '.join(created_codes)}")
    
    return created_codes

def verify_codigo(codigo_str):
    """Verifica se um código de acesso é válido"""
    codigo = CodigoAcesso.query.filter_by(codigo=codigo_str.upper(), ativo=True).first()
    if codigo:
        codigo.update_last_used()
        return codigo
    return None

