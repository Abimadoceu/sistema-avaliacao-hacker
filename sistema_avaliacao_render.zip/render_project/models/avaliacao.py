from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Funcionario(db.Model):
    __tablename__ = 'funcionarios'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    funcao = db.Column(db.String(100), nullable=False)
    setor = db.Column(db.String(100), nullable=False)
    data_admissao = db.Column(db.Date, nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    cadastrado_por_codigo = db.Column(db.String(20), db.ForeignKey('codigos_acesso.codigo'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento com avaliações
    avaliacoes = db.relationship('Avaliacao', backref='funcionario', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'funcao': self.funcao,
            'setor': self.setor,
            'data_admissao': self.data_admissao.isoformat() if self.data_admissao else None,
            'ativo': self.ativo,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Avaliacao(db.Model):
    __tablename__ = 'avaliacoes'
    
    id = db.Column(db.Integer, primary_key=True)
    funcionario_id = db.Column(db.Integer, db.ForeignKey('funcionarios.id'), nullable=False)
    avaliador_codigo = db.Column(db.String(20), db.ForeignKey('codigos_acesso.codigo'), nullable=False)
    avaliador = db.Column(db.String(100), nullable=False)  # Nome do avaliador para exibição
    periodo_inicio = db.Column(db.Date, nullable=False)
    periodo_fim = db.Column(db.Date, nullable=False)
    data_avaliacao = db.Column(db.Date, nullable=False)
    
    # Competências (1-5 para cada uma)
    pontualidade_disciplina = db.Column(db.Integer, nullable=False)
    iniciativa_proatividade = db.Column(db.Integer, nullable=False)
    produtividade_eficiencia = db.Column(db.Integer, nullable=False)
    foco_resultado = db.Column(db.Integer, nullable=False)
    cooperacao_equipe = db.Column(db.Integer, nullable=False)
    autorresponsabilidade = db.Column(db.Integer, nullable=False)
    dinamismo_adaptabilidade = db.Column(db.Integer, nullable=False)
    lideranca_influencia = db.Column(db.Integer, nullable=False)
    criatividade_inovacao = db.Column(db.Integer, nullable=False)
    conhecimento_tecnico = db.Column(db.Integer, nullable=False)
    
    # Comentários
    pontos_fortes = db.Column(db.Text)
    oportunidades_melhoria = db.Column(db.Text)
    metas_desenvolvimento = db.Column(db.Text)
    reconhecimentos = db.Column(db.Text)
    autoavaliacao = db.Column(db.Text)
    
    # Cálculos automáticos
    total_pontos = db.Column(db.Integer)
    media_geral = db.Column(db.Float)
    classificacao = db.Column(db.String(50))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def calcular_totais(self):
        """Calcula total de pontos, média e classificação"""
        competencias = [
            self.pontualidade_disciplina,
            self.iniciativa_proatividade,
            self.produtividade_eficiencia,
            self.foco_resultado,
            self.cooperacao_equipe,
            self.autorresponsabilidade,
            self.dinamismo_adaptabilidade,
            self.lideranca_influencia,
            self.criatividade_inovacao,
            self.conhecimento_tecnico
        ]
        
        self.total_pontos = sum(competencias)
        self.media_geral = self.total_pontos / 10
        
        # Classificação baseada na média
        if self.media_geral >= 5.0:
            self.classificacao = "Excepcional"
        elif self.media_geral >= 4.0:
            self.classificacao = "Acima do Esperado"
        elif self.media_geral >= 3.0:
            self.classificacao = "Satisfatório"
        elif self.media_geral >= 2.0:
            self.classificacao = "Abaixo do Esperado"
        else:
            self.classificacao = "Insatisfatório"
    
    def to_dict(self):
        return {
            'id': self.id,
            'funcionario_id': self.funcionario_id,
            'funcionario_nome': self.funcionario.nome if self.funcionario else None,
            'avaliador': self.avaliador,
            'periodo_inicio': self.periodo_inicio.isoformat() if self.periodo_inicio else None,
            'periodo_fim': self.periodo_fim.isoformat() if self.periodo_fim else None,
            'data_avaliacao': self.data_avaliacao.isoformat() if self.data_avaliacao else None,
            'competencias': {
                'pontualidade_disciplina': self.pontualidade_disciplina,
                'iniciativa_proatividade': self.iniciativa_proatividade,
                'produtividade_eficiencia': self.produtividade_eficiencia,
                'foco_resultado': self.foco_resultado,
                'cooperacao_equipe': self.cooperacao_equipe,
                'autorresponsabilidade': self.autorresponsabilidade,
                'dinamismo_adaptabilidade': self.dinamismo_adaptabilidade,
                'lideranca_influencia': self.lideranca_influencia,
                'criatividade_inovacao': self.criatividade_inovacao,
                'conhecimento_tecnico': self.conhecimento_tecnico
            },
            'comentarios': {
                'pontos_fortes': self.pontos_fortes,
                'oportunidades_melhoria': self.oportunidades_melhoria,
                'metas_desenvolvimento': self.metas_desenvolvimento,
                'reconhecimentos': self.reconhecimentos,
                'autoavaliacao': self.autoavaliacao
            },
            'resultados': {
                'total_pontos': self.total_pontos,
                'media_geral': round(self.media_geral, 2) if self.media_geral else None,
                'classificacao': self.classificacao
            },
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CompetenciaDefinicao(db.Model):
    __tablename__ = 'competencias_definicoes'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    ordem = db.Column(db.Integer, nullable=False)
    ativa = db.Column(db.Boolean, default=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'descricao': self.descricao,
            'ordem': self.ordem,
            'ativa': self.ativa
        }

# Dados iniciais das competências
COMPETENCIAS_INICIAIS = [
    {
        'nome': 'Pontualidade e Disciplina',
        'descricao': 'Cumprimento rigoroso de horários, presença consistente, seguimento de regras e procedimentos estabelecidos',
        'ordem': 1
    },
    {
        'nome': 'Iniciativa e Proatividade',
        'descricao': 'Capacidade de tomar decisões, antecipar problemas, propor soluções e agir sem necessidade de supervisão constante',
        'ordem': 2
    },
    {
        'nome': 'Produtividade e Eficiência',
        'descricao': 'Cumprimento de metas de produção, otimização do tempo de trabalho, uso eficiente de recursos e materiais',
        'ordem': 3
    },
    {
        'nome': 'Foco no Resultado',
        'descricao': 'Orientação para objetivos, persistência na busca de resultados, comprometimento com metas e prazos estabelecidos',
        'ordem': 4
    },
    {
        'nome': 'Cooperação e Trabalho em Equipe',
        'descricao': 'Colaboração efetiva com colegas, apoio mútuo, comunicação clara e resolução construtiva de conflitos',
        'ordem': 5
    },
    {
        'nome': 'Autorresponsabilidade',
        'descricao': 'Responsabilidade pelos próprios atos e resultados, autogestão, autonomia na execução de tarefas e prestação de contas',
        'ordem': 6
    },
    {
        'nome': 'Dinamismo e Adaptabilidade',
        'descricao': 'Energia e agilidade na execução de tarefas, flexibilidade a mudanças, adaptação a novas tecnologias e processos',
        'ordem': 7
    },
    {
        'nome': 'Liderança e Influência',
        'descricao': 'Capacidade de orientar e influenciar colegas, servir de exemplo positivo, contribuir para o desenvolvimento da equipe',
        'ordem': 8
    },
    {
        'nome': 'Criatividade e Inovação',
        'descricao': 'Capacidade de propor ideias inovadoras, soluções criativas para problemas, melhoria contínua de processos',
        'ordem': 9
    },
    {
        'nome': 'Conhecimento Técnico e Qualidade',
        'descricao': 'Domínio das competências técnicas da função, atenção à qualidade, cumprimento de normas de segurança e padrões',
        'ordem': 10
    }
]

def init_competencias():
    """Inicializa as competências padrão no banco de dados"""
    for comp_data in COMPETENCIAS_INICIAIS:
        competencia = CompetenciaDefinicao.query.filter_by(nome=comp_data['nome']).first()
        if not competencia:
            competencia = CompetenciaDefinicao(**comp_data)
            db.session.add(competencia)
    
    db.session.commit()

