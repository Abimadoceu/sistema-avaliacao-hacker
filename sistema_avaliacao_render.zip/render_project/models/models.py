from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
import secrets
import string
import hashlib

db = SQLAlchemy()

class CodigoAcesso(db.Model):
    __tablename__ = 'codigos_acesso'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(20), unique=True, nullable=False)
    senha = db.Column(db.String(255))  # Para gestores
    nome_usuario = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(20), nullable=False)  # 'gestor', 'avaliador'
    ativo = db.Column(db.Boolean, default=True)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    ultimo_acesso = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<CodigoAcesso {self.codigo}>'
    
    def is_gestor(self):
        return self.tipo == 'gestor'
    
    def is_avaliador(self):
        return self.tipo == 'avaliador'
    
    def verificar_senha(self, senha):
        """Verifica senha para gestores"""
        if not self.senha:
            return True  # Avaliadores não têm senha
        return hashlib.sha256(senha.encode()).hexdigest() == self.senha
    
    def definir_senha(self, senha):
        """Define senha para gestores"""
        self.senha = hashlib.sha256(senha.encode()).hexdigest()
    
    def can_access_funcionario(self, funcionario):
        """Verifica se o código pode acessar um funcionário específico"""
        if self.is_gestor():
            return True
        return funcionario.cadastrado_por_codigo == self.codigo
    
    def can_access_avaliacao(self, avaliacao):
        """Verifica se o código pode acessar uma avaliação específica"""
        if self.is_gestor():
            return True
        # Avaliador pode ver avaliações que ele fez
        return avaliacao.avaliador_codigo == self.codigo
    
    def to_dict(self):
        return {
            'id': self.id,
            'codigo': self.codigo,
            'nome_usuario': self.nome_usuario,
            'tipo': self.tipo,
            'is_gestor': self.is_gestor(),
            'is_avaliador': self.is_avaliador(),
            'tem_senha': bool(self.senha),
            'ativo': self.ativo,
            'data_criacao': self.data_criacao.isoformat() if self.data_criacao else None,
            'ultimo_acesso': self.ultimo_acesso.isoformat() if self.ultimo_acesso else None
        }

class Funcionario(db.Model):
    __tablename__ = 'funcionarios'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    funcao = db.Column(db.String(100), nullable=False)
    setor = db.Column(db.String(100), nullable=False)
    data_admissao = db.Column(db.Date, nullable=False)
    cadastrado_por_codigo = db.Column(db.String(20), nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    data_cadastro = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento com avaliações
    avaliacoes = db.relationship('Avaliacao', backref='funcionario', lazy=True)
    
    def __repr__(self):
        return f'<Funcionario {self.nome}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'funcao': self.funcao,
            'setor': self.setor,
            'data_admissao': self.data_admissao.isoformat(),
            'cadastrado_por_codigo': self.cadastrado_por_codigo,
            'ativo': self.ativo,
            'data_cadastro': self.data_cadastro.isoformat() if self.data_cadastro else None
        }

class Avaliacao(db.Model):
    __tablename__ = 'avaliacoes'
    
    id = db.Column(db.Integer, primary_key=True)
    funcionario_id = db.Column(db.Integer, db.ForeignKey('funcionarios.id'), nullable=False)
    avaliador_codigo = db.Column(db.String(20), nullable=False)
    avaliador_nome = db.Column(db.String(100), nullable=False)
    periodo_inicio = db.Column(db.Date, nullable=False)
    periodo_fim = db.Column(db.Date, nullable=False)
    data_avaliacao = db.Column(db.Date, nullable=False)
    
    # Competências (1-5)
    pontualidade_disciplina = db.Column(db.Integer, nullable=False)
    iniciativa_proatividade = db.Column(db.Integer, nullable=False)
    produtividade_eficiencia = db.Column(db.Integer, nullable=False)
    foco_resultado = db.Column(db.Integer, nullable=False)
    cooperacao_equipe = db.Column(db.Integer, nullable=False)
    autorresponsabilidade = db.Column(db.Integer, nullable=False)
    dinamismo_adaptabilidade = db.Column(db.Integer, nullable=False)
    lideranca_influencia = db.Column(db.Integer, nullable=False)
    criatividade_inovacao = db.Column(db.Integer, nullable=False)
    conhecimento_tecnico = db.Column(db.Integer, nullable=False)
    
    # Comentários
    pontos_fortes = db.Column(db.Text)
    oportunidades_melhoria = db.Column(db.Text)
    metas_desenvolvimento = db.Column(db.Text)
    reconhecimentos = db.Column(db.Text)
    autoavaliacao = db.Column(db.Text)
    
    # Novo: Feedback do líder
    feedback_lider = db.Column(db.Text)
    lider_nome = db.Column(db.String(100))
    
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Avaliacao {self.funcionario.nome} - {self.data_avaliacao}>'
    
    def calcular_media(self):
        """Calcula a média das competências"""
        competencias = [
            self.pontualidade_disciplina, self.iniciativa_proatividade,
            self.produtividade_eficiencia, self.foco_resultado,
            self.cooperacao_equipe, self.autorresponsabilidade,
            self.dinamismo_adaptabilidade, self.lideranca_influencia,
            self.criatividade_inovacao, self.conhecimento_tecnico
        ]
        return sum(competencias) / len(competencias)
    
    def get_classificacao(self):
        """Retorna a classificação baseada na média"""
        media = self.calcular_media()
        if media >= 5.0:
            return 'Excepcional'
        elif media >= 4.0:
            return 'Acima do Esperado'
        elif media >= 3.0:
            return 'Satisfatório'
        elif media >= 2.0:
            return 'Abaixo do Esperado'
        else:
            return 'Insatisfatório'
    
    def to_dict(self):
        media = self.calcular_media()
        return {
            'id': self.id,
            'funcionario_id': self.funcionario_id,
            'funcionario_nome': self.funcionario.nome,
            'funcionario_funcao': self.funcionario.funcao,
            'funcionario_setor': self.funcionario.setor,
            'avaliador_codigo': self.avaliador_codigo,
            'avaliador_nome': self.avaliador_nome,
            'periodo_inicio': self.periodo_inicio.isoformat(),
            'periodo_fim': self.periodo_fim.isoformat(),
            'data_avaliacao': self.data_avaliacao.isoformat(),
            'pontualidade_disciplina': self.pontualidade_disciplina,
            'iniciativa_proatividade': self.iniciativa_proatividade,
            'produtividade_eficiencia': self.produtividade_eficiencia,
            'foco_resultado': self.foco_resultado,
            'cooperacao_equipe': self.cooperacao_equipe,
            'autorresponsabilidade': self.autorresponsabilidade,
            'dinamismo_adaptabilidade': self.dinamismo_adaptabilidade,
            'lideranca_influencia': self.lideranca_influencia,
            'criatividade_inovacao': self.criatividade_inovacao,
            'conhecimento_tecnico': self.conhecimento_tecnico,
            'pontos_fortes': self.pontos_fortes,
            'oportunidades_melhoria': self.oportunidades_melhoria,
            'metas_desenvolvimento': self.metas_desenvolvimento,
            'reconhecimentos': self.reconhecimentos,
            'autoavaliacao': self.autoavaliacao,
            'feedback_lider': self.feedback_lider,
            'lider_nome': self.lider_nome,
            'media': round(media, 2),
            'classificacao': self.get_classificacao(),
            'data_criacao': self.data_criacao.isoformat() if self.data_criacao else None
        }

class CompetenciaDefinicao(db.Model):
    __tablename__ = 'competencias_definicao'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    ordem = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f'<CompetenciaDefinicao {self.nome}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'descricao': self.descricao,
            'ordem': self.ordem
        }

def create_gestores_avaliadores():
    """Cria 3 gestores e 40 avaliadores"""
    
    # 3 Gestores com senhas específicas
    gestores = [
        {'codigo': 'GESTOR01', 'nome': 'Gestor Principal', 'senha': 'hacker2025'},
        {'codigo': 'GESTOR02', 'nome': 'Gestor Operacional', 'senha': 'industrial2025'},
        {'codigo': 'GESTOR03', 'nome': 'Gestor Administrativo', 'senha': 'feedback2025'}
    ]
    
    # 40 Avaliadores (sem senha)
    avaliadores = []
    for i in range(1, 41):
        codigo = f'AVAL{i:03d}'  # AVAL001, AVAL002, etc.
        nome = f'Avaliador {i}'
        avaliadores.append({'codigo': codigo, 'nome': nome})
    
    # Criar gestores
    for gestor_data in gestores:
        existing = CodigoAcesso.query.filter_by(codigo=gestor_data['codigo']).first()
        if not existing:
            gestor = CodigoAcesso(
                codigo=gestor_data['codigo'],
                nome_usuario=gestor_data['nome'],
                tipo='gestor'
            )
            gestor.definir_senha(gestor_data['senha'])
            db.session.add(gestor)
    
    # Criar avaliadores
    for aval_data in avaliadores:
        existing = CodigoAcesso.query.filter_by(codigo=aval_data['codigo']).first()
        if not existing:
            avaliador = CodigoAcesso(
                codigo=aval_data['codigo'],
                nome_usuario=aval_data['nome'],
                tipo='avaliador'
            )
            db.session.add(avaliador)
    
    try:
        db.session.commit()
        print(f"✅ Criados 3 gestores e 40 avaliadores com sucesso!")
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro ao criar gestores e avaliadores: {e}")

def init_competencias():
    """Inicializa as competências padrão"""
    competencias_padrao = [
        {
            'nome': 'Pontualidade e Disciplina',
            'descricao': 'Cumprimento de horários, regras e procedimentos da empresa',
            'ordem': 1
        },
        {
            'nome': 'Iniciativa e Proatividade',
            'descricao': 'Capacidade de agir sem supervisão e antecipar necessidades',
            'ordem': 2
        },
        {
            'nome': 'Produtividade e Eficiência',
            'descricao': 'Cumprimento de metas e otimização de processos',
            'ordem': 3
        },
        {
            'nome': 'Foco no Resultado',
            'descricao': 'Orientação para objetivos e persistência na busca de soluções',
            'ordem': 4
        },
        {
            'nome': 'Cooperação e Trabalho em Equipe',
            'descricao': 'Colaboração efetiva e relacionamento interpessoal',
            'ordem': 5
        },
        {
            'nome': 'Autorresponsabilidade',
            'descricao': 'Responsabilidade pessoal e autonomia nas atividades',
            'ordem': 6
        },
        {
            'nome': 'Dinamismo e Adaptabilidade',
            'descricao': 'Flexibilidade a mudanças e energia para novos desafios',
            'ordem': 7
        },
        {
            'nome': 'Liderança e Influência',
            'descricao': 'Capacidade de liderar e influenciar positivamente',
            'ordem': 8
        },
        {
            'nome': 'Criatividade e Inovação',
            'descricao': 'Pensamento inovador e busca por melhorias',
            'ordem': 9
        },
        {
            'nome': 'Conhecimento Técnico e Qualidade',
            'descricao': 'Competência técnica e manutenção de padrões de qualidade',
            'ordem': 10
        }
    ]
    
    for comp_data in competencias_padrao:
        existing = CompetenciaDefinicao.query.filter_by(nome=comp_data['nome']).first()
        if not existing:
            competencia = CompetenciaDefinicao(
                nome=comp_data['nome'],
                descricao=comp_data['descricao'],
                ordem=comp_data['ordem']
            )
            db.session.add(competencia)
    
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Erro ao inicializar competências: {e}")



class Competencia(db.Model):
    __tablename__ = 'competencias'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text)
    ativo = db.Column(db.Boolean, default=True)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Competencia {self.nome}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'descricao': self.descricao,
            'ativo': self.ativo,
            'data_criacao': self.data_criacao.isoformat() if self.data_criacao else None
        }

