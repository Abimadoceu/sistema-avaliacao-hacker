from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import jwt
import os

db = SQLAlchemy()

class Usuario(db.Model):
    __tablename__ = 'usuarios'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    senha_hash = db.Column(db.String(255), nullable=False)
    tipo = db.Column(db.String(20), nullable=False, default='avaliador')  # 'admin', 'avaliador'
    ativo = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relacionamentos
    funcionarios_cadastrados = db.relationship('Funcionario', backref='cadastrado_por_usuario', lazy=True, foreign_keys='Funcionario.cadastrado_por')
    avaliacoes_realizadas = db.relationship('Avaliacao', backref='avaliador_usuario', lazy=True, foreign_keys='Avaliacao.avaliador_id')
    
    def set_password(self, password):
        """Define a senha do usuário com hash"""
        self.senha_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Verifica se a senha está correta"""
        return check_password_hash(self.senha_hash, password)
    
    def generate_token(self):
        """Gera token JWT para autenticação"""
        payload = {
            'user_id': self.id,
            'email': self.email,
            'tipo': self.tipo,
            'exp': datetime.utcnow() + timedelta(hours=24)  # Token válido por 24 horas
        }
        return jwt.encode(payload, os.environ.get('SECRET_KEY', 'hacker_industrial_secret'), algorithm='HS256')
    
    @staticmethod
    def verify_token(token):
        """Verifica e decodifica token JWT"""
        try:
            payload = jwt.decode(token, os.environ.get('SECRET_KEY', 'hacker_industrial_secret'), algorithms=['HS256'])
            return Usuario.query.get(payload['user_id'])
        except jwt.ExpiredSignatureError:
            return None  # Token expirado
        except jwt.InvalidTokenError:
            return None  # Token inválido
    
    def is_admin(self):
        """Verifica se o usuário é administrador"""
        return self.tipo == 'admin'
    
    def can_access_funcionario(self, funcionario):
        """Verifica se o usuário pode acessar dados de um funcionário"""
        if self.is_admin():
            return True
        return funcionario.cadastrado_por == self.id
    
    def can_access_avaliacao(self, avaliacao):
        """Verifica se o usuário pode acessar uma avaliação"""
        if self.is_admin():
            return True
        # Pode acessar se foi quem fez a avaliação OU se cadastrou o funcionário
        return (avaliacao.avaliador_id == self.id or 
                avaliacao.funcionario.cadastrado_por == self.id)
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'tipo': self.tipo,
            'ativo': self.ativo,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }

class SessaoUsuario(db.Model):
    __tablename__ = 'sessoes_usuarios'
    
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    token = db.Column(db.String(500), nullable=False, unique=True)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    
    usuario = db.relationship('Usuario', backref='sessoes')
    
    def is_valid(self):
        """Verifica se a sessão ainda é válida"""
        return self.ativo and datetime.utcnow() < self.expires_at
    
    def invalidate(self):
        """Invalida a sessão"""
        self.ativo = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'usuario_id': self.usuario_id,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'ativo': self.ativo
        }

def create_admin_user():
    """Cria usuário administrador padrão se não existir"""
    admin = Usuario.query.filter_by(email='admin@hackerindustrial.com').first()
    if not admin:
        admin = Usuario(
            nome='Administrador',
            email='admin@hackerindustrial.com',
            tipo='admin'
        )
        admin.set_password('admin123')  # Senha padrão - deve ser alterada
        db.session.add(admin)
        db.session.commit()
        print("Usuário administrador criado: admin@hackerindustrial.com / admin123")
    return admin

