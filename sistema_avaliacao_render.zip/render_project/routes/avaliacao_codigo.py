from flask import Blueprint, request, jsonify
from datetime import datetime, date
from models.models import db, Funcionario, Avaliacao, CompetenciaDefinicao, CodigoAcesso
from routes.codigo_auth import codigo_required, gestor_required
from sqlalchemy import desc, or_

avaliacao_codigo_bp = Blueprint('avaliacao_codigo', __name__)

# ROTAS PARA FUNCIONÁRIOS
@avaliacao_codigo_bp.route('/funcionarios', methods=['GET'])
@codigo_required
def get_funcionarios(codigo):
    """Lista funcionários baseado no código de acesso"""
    try:
        if codigo.is_gestor():
            # Gestor vê todos os funcionários
            funcionarios = Funcionario.query.filter_by(ativo=True).order_by(Funcionario.nome).all()
        else:
            # Avaliador vê todos os funcionários (para poder avaliar qualquer um)
            funcionarios = Funcionario.query.filter_by(ativo=True).order_by(Funcionario.nome).all()
        
        return jsonify({
            'success': True,
            'data': [f.to_dict() for f in funcionarios]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/funcionarios', methods=['POST'])
@codigo_required
@gestor_required
def create_funcionario(codigo):
    """Cria novo funcionário (apenas gestores)"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['nome', 'funcao', 'setor', 'data_admissao']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Campo {field} é obrigatório'}), 400
        
        # Converter data
        try:
            data_admissao = datetime.strptime(data['data_admissao'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'success': False, 'error': 'Data de admissão deve estar no formato YYYY-MM-DD'}), 400
        
        funcionario = Funcionario(
            nome=data['nome'],
            funcao=data['funcao'],
            setor=data['setor'],
            data_admissao=data_admissao,
            cadastrado_por_codigo=codigo.codigo
        )
        
        db.session.add(funcionario)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': funcionario.to_dict(),
            'message': 'Funcionário cadastrado com sucesso'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/funcionarios/<int:funcionario_id>', methods=['GET'])
@codigo_required
def get_funcionario(codigo, funcionario_id):
    """Retorna dados de um funcionário específico"""
    try:
        funcionario = Funcionario.query.get_or_404(funcionario_id)
        
        return jsonify({
            'success': True,
            'data': funcionario.to_dict()
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ROTAS PARA AVALIAÇÕES
@avaliacao_codigo_bp.route('/avaliacoes', methods=['GET'])
@codigo_required
def get_avaliacoes(codigo):
    """Lista avaliações baseado no código de acesso"""
    try:
        if codigo.is_gestor():
            # Gestor vê todas as avaliações
            avaliacoes = Avaliacao.query.order_by(desc(Avaliacao.data_avaliacao)).all()
        else:
            # Avaliador vê apenas avaliações que ele fez
            avaliacoes = Avaliacao.query.filter_by(avaliador_codigo=codigo.codigo).order_by(desc(Avaliacao.data_avaliacao)).all()
        
        return jsonify({
            'success': True,
            'data': [a.to_dict() for a in avaliacoes]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/avaliacoes', methods=['POST'])
@codigo_required
def create_avaliacao(codigo):
    """Cria nova avaliação"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['funcionario_id', 'avaliador_codigo', 'avaliador_nome', 'periodo_inicio', 'periodo_fim', 'data_avaliacao']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se o funcionário existe
        funcionario = Funcionario.query.get(data['funcionario_id'])
        if not funcionario:
            return jsonify({'success': False, 'error': 'Funcionário não encontrado'}), 404
        
        # Verificar se o avaliador existe
        avaliador = CodigoAcesso.query.filter_by(codigo=data['avaliador_codigo'], ativo=True).first()
        if not avaliador:
            return jsonify({'success': False, 'error': 'Avaliador não encontrado'}), 404
        
        # Converter datas
        try:
            periodo_inicio = datetime.strptime(data['periodo_inicio'], '%Y-%m-%d').date()
            periodo_fim = datetime.strptime(data['periodo_fim'], '%Y-%m-%d').date()
            data_avaliacao = datetime.strptime(data['data_avaliacao'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'success': False, 'error': 'Datas devem estar no formato YYYY-MM-DD'}), 400
        
        # Validar competências
        competencias = [
            'pontualidade_disciplina', 'iniciativa_proatividade', 'produtividade_eficiencia',
            'foco_resultado', 'cooperacao_equipe', 'autorresponsabilidade',
            'dinamismo_adaptabilidade', 'lideranca_influencia', 'criatividade_inovacao',
            'conhecimento_tecnico'
        ]
        
        for comp in competencias:
            if comp not in data or not isinstance(data[comp], int) or data[comp] < 1 or data[comp] > 5:
                return jsonify({'success': False, 'error': f'Competência {comp} deve ser um número entre 1 e 5'}), 400
        
        avaliacao = Avaliacao(
            funcionario_id=data['funcionario_id'],
            avaliador_codigo=data['avaliador_codigo'],
            avaliador_nome=data['avaliador_nome'],
            periodo_inicio=periodo_inicio,
            periodo_fim=periodo_fim,
            data_avaliacao=data_avaliacao,
            pontualidade_disciplina=data['pontualidade_disciplina'],
            iniciativa_proatividade=data['iniciativa_proatividade'],
            produtividade_eficiencia=data['produtividade_eficiencia'],
            foco_resultado=data['foco_resultado'],
            cooperacao_equipe=data['cooperacao_equipe'],
            autorresponsabilidade=data['autorresponsabilidade'],
            dinamismo_adaptabilidade=data['dinamismo_adaptabilidade'],
            lideranca_influencia=data['lideranca_influencia'],
            criatividade_inovacao=data['criatividade_inovacao'],
            conhecimento_tecnico=data['conhecimento_tecnico'],
            pontos_fortes=data.get('pontos_fortes', ''),
            oportunidades_melhoria=data.get('oportunidades_melhoria', ''),
            metas_desenvolvimento=data.get('metas_desenvolvimento', ''),
            reconhecimentos=data.get('reconhecimentos', ''),
            autoavaliacao=data.get('autoavaliacao', ''),
            feedback_lider=data.get('feedback_lider', ''),
            lider_nome=data.get('lider_nome', '')
        )
        
        db.session.add(avaliacao)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': avaliacao.to_dict(),
            'message': 'Avaliação criada com sucesso'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/avaliacoes/<int:avaliacao_id>', methods=['GET'])
@codigo_required
def get_avaliacao(codigo, avaliacao_id):
    """Retorna dados de uma avaliação específica"""
    try:
        avaliacao = Avaliacao.query.get_or_404(avaliacao_id)
        
        # Verificar permissão de acesso
        if not codigo.can_access_avaliacao(avaliacao):
            return jsonify({'success': False, 'error': 'Acesso negado a esta avaliação'}), 403
        
        return jsonify({
            'success': True,
            'data': avaliacao.to_dict()
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/avaliacoes/<int:avaliacao_id>', methods=['PUT'])
@codigo_required
def update_avaliacao(codigo, avaliacao_id):
    """Atualiza uma avaliação (para adicionar feedback do líder)"""
    try:
        avaliacao = Avaliacao.query.get_or_404(avaliacao_id)
        
        # Verificar permissão de acesso
        if not codigo.can_access_avaliacao(avaliacao):
            return jsonify({'success': False, 'error': 'Acesso negado a esta avaliação'}), 403
        
        data = request.get_json()
        
        # Atualizar campos permitidos
        if 'feedback_lider' in data:
            avaliacao.feedback_lider = data['feedback_lider']
        if 'lider_nome' in data:
            avaliacao.lider_nome = data['lider_nome']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': avaliacao.to_dict(),
            'message': 'Avaliação atualizada com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/avaliacoes/funcionario/<int:funcionario_id>', methods=['GET'])
@codigo_required
def get_avaliacoes_funcionario(codigo, funcionario_id):
    """Lista avaliações de um funcionário específico"""
    try:
        funcionario = Funcionario.query.get_or_404(funcionario_id)
        
        if codigo.is_gestor():
            # Gestor vê todas as avaliações do funcionário
            avaliacoes = Avaliacao.query.filter_by(funcionario_id=funcionario_id).order_by(desc(Avaliacao.data_avaliacao)).all()
        else:
            # Avaliador vê apenas suas avaliações do funcionário
            avaliacoes = Avaliacao.query.filter_by(
                funcionario_id=funcionario_id,
                avaliador_codigo=codigo.codigo
            ).order_by(desc(Avaliacao.data_avaliacao)).all()
        
        return jsonify({
            'success': True,
            'data': [a.to_dict() for a in avaliacoes]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ROTAS PARA COMPETÊNCIAS
@avaliacao_codigo_bp.route('/competencias', methods=['GET'])
@codigo_required
def get_competencias(codigo):
    """Lista todas as competências definidas"""
    try:
        competencias = CompetenciaDefinicao.query.order_by(CompetenciaDefinicao.ordem).all()
        return jsonify({
            'success': True,
            'data': [c.to_dict() for c in competencias]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ROTAS PARA DASHBOARD
@avaliacao_codigo_bp.route('/dashboard', methods=['GET'])
@codigo_required
def get_dashboard(codigo):
    """Retorna dados do dashboard baseado no código de acesso"""
    try:
        if codigo.is_gestor():
            # Gestor vê estatísticas gerais
            total_funcionarios = Funcionario.query.filter_by(ativo=True).count()
            total_avaliacoes = Avaliacao.query.count()
            
            # Média geral de todas as avaliações
            avaliacoes = Avaliacao.query.all()
            
            # Últimas avaliações
            ultimas_avaliacoes = Avaliacao.query.order_by(desc(Avaliacao.data_avaliacao)).limit(5).all()
        else:
            # Avaliador vê apenas suas estatísticas
            total_funcionarios = Funcionario.query.filter_by(ativo=True).count()
            
            # Avaliações que ele fez
            avaliacoes = Avaliacao.query.filter_by(avaliador_codigo=codigo.codigo).all()
            total_avaliacoes = len(avaliacoes)
            
            # Últimas avaliações que ele fez
            ultimas_avaliacoes = Avaliacao.query.filter_by(
                avaliador_codigo=codigo.codigo
            ).order_by(desc(Avaliacao.data_avaliacao)).limit(5).all()
        
        # Calcular média geral
        if avaliacoes:
            total_pontos = sum(a.calcular_media() for a in avaliacoes)
            media_geral = total_pontos / len(avaliacoes)
        else:
            media_geral = 0
        
        return jsonify({
            'success': True,
            'data': {
                'total_funcionarios': total_funcionarios,
                'total_avaliacoes': total_avaliacoes,
                'media_geral': round(media_geral, 2),
                'ultimas_avaliacoes': [a.to_dict() for a in ultimas_avaliacoes],
                'tipo_acesso': codigo.tipo,
                'nome_usuario': codigo.nome_usuario
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_codigo_bp.route('/health', methods=['GET'])
def health_check():
    """Health check da API"""
    return jsonify({
        'success': True,
        'message': 'API funcionando corretamente',
        'timestamp': datetime.utcnow().isoformat()
    })

