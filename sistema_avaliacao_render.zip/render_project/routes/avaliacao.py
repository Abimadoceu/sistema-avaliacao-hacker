from flask import Blueprint, request, jsonify
from datetime import datetime, date
from src.models.avaliacao import db, Funcionario, Avaliacao, CompetenciaDefinicao, init_competencias
from src.routes.auth import token_required, admin_required
from sqlalchemy import desc, or_

avaliacao_bp = Blueprint('avaliacao', __name__)

# Função para inicializar competências será chamada no main.py

# ROTAS PARA FUNCIONÁRIOS
@avaliacao_bp.route('/funcionarios', methods=['GET'])
def get_funcionarios():
    """Lista todos os funcionários ativos"""
    try:
        funcionarios = Funcionario.query.filter_by(ativo=True).order_by(Funcionario.nome).all()
        return jsonify({
            'success': True,
            'data': [f.to_dict() for f in funcionarios]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/funcionarios', methods=['POST'])
def create_funcionario():
    """Cria um novo funcionário"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['nome', 'funcao', 'setor', 'data_admissao']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Campo {field} é obrigatório'}), 400
        
        # Converter data de admissão
        data_admissao = datetime.strptime(data['data_admissao'], '%Y-%m-%d').date()
        
        funcionario = Funcionario(
            nome=data['nome'],
            funcao=data['funcao'],
            setor=data['setor'],
            data_admissao=data_admissao
        )
        
        db.session.add(funcionario)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': funcionario.to_dict(),
            'message': 'Funcionário criado com sucesso'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/funcionarios/<int:funcionario_id>', methods=['GET'])
def get_funcionario(funcionario_id):
    """Busca um funcionário específico"""
    try:
        funcionario = Funcionario.query.get_or_404(funcionario_id)
        return jsonify({
            'success': True,
            'data': funcionario.to_dict()
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ROTAS PARA AVALIAÇÕES
@avaliacao_bp.route('/avaliacoes', methods=['GET'])
def get_avaliacoes():
    """Lista todas as avaliações"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        funcionario_id = request.args.get('funcionario_id', type=int)
        
        query = Avaliacao.query
        
        if funcionario_id:
            query = query.filter_by(funcionario_id=funcionario_id)
        
        avaliacoes = query.order_by(desc(Avaliacao.data_avaliacao)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'success': True,
            'data': [a.to_dict() for a in avaliacoes.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': avaliacoes.total,
                'pages': avaliacoes.pages,
                'has_next': avaliacoes.has_next,
                'has_prev': avaliacoes.has_prev
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/avaliacoes', methods=['POST'])
def create_avaliacao():
    """Cria uma nova avaliação"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['funcionario_id', 'avaliador', 'periodo_inicio', 'periodo_fim', 'data_avaliacao']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Campo {field} é obrigatório'}), 400
        
        # Validar competências
        competencias = data.get('competencias', {})
        required_competencias = [
            'pontualidade_disciplina', 'iniciativa_proatividade', 'produtividade_eficiencia',
            'foco_resultado', 'cooperacao_equipe', 'autorresponsabilidade',
            'dinamismo_adaptabilidade', 'lideranca_influencia', 'criatividade_inovacao',
            'conhecimento_tecnico'
        ]
        
        for comp in required_competencias:
            if comp not in competencias:
                return jsonify({'success': False, 'error': f'Competência {comp} é obrigatória'}), 400
            if not isinstance(competencias[comp], int) or competencias[comp] < 1 or competencias[comp] > 5:
                return jsonify({'success': False, 'error': f'Competência {comp} deve ser um número entre 1 e 5'}), 400
        
        # Converter datas
        periodo_inicio = datetime.strptime(data['periodo_inicio'], '%Y-%m-%d').date()
        periodo_fim = datetime.strptime(data['periodo_fim'], '%Y-%m-%d').date()
        data_avaliacao = datetime.strptime(data['data_avaliacao'], '%Y-%m-%d').date()
        
        # Criar avaliação
        avaliacao = Avaliacao(
            funcionario_id=data['funcionario_id'],
            avaliador=data['avaliador'],
            periodo_inicio=periodo_inicio,
            periodo_fim=periodo_fim,
            data_avaliacao=data_avaliacao,
            pontualidade_disciplina=competencias['pontualidade_disciplina'],
            iniciativa_proatividade=competencias['iniciativa_proatividade'],
            produtividade_eficiencia=competencias['produtividade_eficiencia'],
            foco_resultado=competencias['foco_resultado'],
            cooperacao_equipe=competencias['cooperacao_equipe'],
            autorresponsabilidade=competencias['autorresponsabilidade'],
            dinamismo_adaptabilidade=competencias['dinamismo_adaptabilidade'],
            lideranca_influencia=competencias['lideranca_influencia'],
            criatividade_inovacao=competencias['criatividade_inovacao'],
            conhecimento_tecnico=competencias['conhecimento_tecnico'],
            pontos_fortes=data.get('comentarios', {}).get('pontos_fortes', ''),
            oportunidades_melhoria=data.get('comentarios', {}).get('oportunidades_melhoria', ''),
            metas_desenvolvimento=data.get('comentarios', {}).get('metas_desenvolvimento', ''),
            reconhecimentos=data.get('comentarios', {}).get('reconhecimentos', ''),
            autoavaliacao=data.get('comentarios', {}).get('autoavaliacao', '')
        )
        
        # Calcular totais
        avaliacao.calcular_totais()
        
        db.session.add(avaliacao)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': avaliacao.to_dict(),
            'message': 'Avaliação criada com sucesso'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/avaliacoes/<int:avaliacao_id>', methods=['GET'])
def get_avaliacao(avaliacao_id):
    """Busca uma avaliação específica"""
    try:
        avaliacao = Avaliacao.query.get_or_404(avaliacao_id)
        return jsonify({
            'success': True,
            'data': avaliacao.to_dict()
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/avaliacoes/<int:avaliacao_id>', methods=['PUT'])
def update_avaliacao(avaliacao_id):
    """Atualiza uma avaliação existente"""
    try:
        avaliacao = Avaliacao.query.get_or_404(avaliacao_id)
        data = request.get_json()
        
        # Atualizar campos básicos
        if 'avaliador' in data:
            avaliacao.avaliador = data['avaliador']
        if 'periodo_inicio' in data:
            avaliacao.periodo_inicio = datetime.strptime(data['periodo_inicio'], '%Y-%m-%d').date()
        if 'periodo_fim' in data:
            avaliacao.periodo_fim = datetime.strptime(data['periodo_fim'], '%Y-%m-%d').date()
        if 'data_avaliacao' in data:
            avaliacao.data_avaliacao = datetime.strptime(data['data_avaliacao'], '%Y-%m-%d').date()
        
        # Atualizar competências
        if 'competencias' in data:
            competencias = data['competencias']
            avaliacao.pontualidade_disciplina = competencias.get('pontualidade_disciplina', avaliacao.pontualidade_disciplina)
            avaliacao.iniciativa_proatividade = competencias.get('iniciativa_proatividade', avaliacao.iniciativa_proatividade)
            avaliacao.produtividade_eficiencia = competencias.get('produtividade_eficiencia', avaliacao.produtividade_eficiencia)
            avaliacao.foco_resultado = competencias.get('foco_resultado', avaliacao.foco_resultado)
            avaliacao.cooperacao_equipe = competencias.get('cooperacao_equipe', avaliacao.cooperacao_equipe)
            avaliacao.autorresponsabilidade = competencias.get('autorresponsabilidade', avaliacao.autorresponsabilidade)
            avaliacao.dinamismo_adaptabilidade = competencias.get('dinamismo_adaptabilidade', avaliacao.dinamismo_adaptabilidade)
            avaliacao.lideranca_influencia = competencias.get('lideranca_influencia', avaliacao.lideranca_influencia)
            avaliacao.criatividade_inovacao = competencias.get('criatividade_inovacao', avaliacao.criatividade_inovacao)
            avaliacao.conhecimento_tecnico = competencias.get('conhecimento_tecnico', avaliacao.conhecimento_tecnico)
        
        # Atualizar comentários
        if 'comentarios' in data:
            comentarios = data['comentarios']
            avaliacao.pontos_fortes = comentarios.get('pontos_fortes', avaliacao.pontos_fortes)
            avaliacao.oportunidades_melhoria = comentarios.get('oportunidades_melhoria', avaliacao.oportunidades_melhoria)
            avaliacao.metas_desenvolvimento = comentarios.get('metas_desenvolvimento', avaliacao.metas_desenvolvimento)
            avaliacao.reconhecimentos = comentarios.get('reconhecimentos', avaliacao.reconhecimentos)
            avaliacao.autoavaliacao = comentarios.get('autoavaliacao', avaliacao.autoavaliacao)
        
        # Recalcular totais
        avaliacao.calcular_totais()
        avaliacao.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': avaliacao.to_dict(),
            'message': 'Avaliação atualizada com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/avaliacoes/<int:avaliacao_id>', methods=['DELETE'])
def delete_avaliacao(avaliacao_id):
    """Exclui uma avaliação"""
    try:
        avaliacao = Avaliacao.query.get_or_404(avaliacao_id)
        db.session.delete(avaliacao)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Avaliação excluída com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

# ROTAS PARA COMPETÊNCIAS
@avaliacao_bp.route('/competencias', methods=['GET'])
def get_competencias():
    """Lista todas as competências definidas"""
    try:
        competencias = CompetenciaDefinicao.query.filter_by(ativa=True).order_by(CompetenciaDefinicao.ordem).all()
        return jsonify({
            'success': True,
            'data': [c.to_dict() for c in competencias]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ROTAS PARA RELATÓRIOS
@avaliacao_bp.route('/relatorios/funcionario/<int:funcionario_id>', methods=['GET'])
def relatorio_funcionario(funcionario_id):
    """Relatório de avaliações de um funcionário"""
    try:
        funcionario = Funcionario.query.get_or_404(funcionario_id)
        avaliacoes = Avaliacao.query.filter_by(funcionario_id=funcionario_id).order_by(desc(Avaliacao.data_avaliacao)).all()
        
        # Calcular estatísticas
        if avaliacoes:
            medias = [a.media_geral for a in avaliacoes if a.media_geral]
            media_historica = sum(medias) / len(medias) if medias else 0
            
            # Evolução das competências
            evolucao = {}
            competencias_nomes = [
                'pontualidade_disciplina', 'iniciativa_proatividade', 'produtividade_eficiencia',
                'foco_resultado', 'cooperacao_equipe', 'autorresponsabilidade',
                'dinamismo_adaptabilidade', 'lideranca_influencia', 'criatividade_inovacao',
                'conhecimento_tecnico'
            ]
            
            for comp in competencias_nomes:
                evolucao[comp] = [getattr(a, comp) for a in reversed(avaliacoes)]
        else:
            media_historica = 0
            evolucao = {}
        
        return jsonify({
            'success': True,
            'data': {
                'funcionario': funcionario.to_dict(),
                'avaliacoes': [a.to_dict() for a in avaliacoes],
                'estatisticas': {
                    'total_avaliacoes': len(avaliacoes),
                    'media_historica': round(media_historica, 2),
                    'evolucao_competencias': evolucao
                }
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@avaliacao_bp.route('/relatorios/geral', methods=['GET'])
def relatorio_geral():
    """Relatório geral de todas as avaliações"""
    try:
        # Estatísticas gerais
        total_funcionarios = Funcionario.query.filter_by(ativo=True).count()
        total_avaliacoes = Avaliacao.query.count()
        
        # Média geral de todas as avaliações
        avaliacoes = Avaliacao.query.all()
        if avaliacoes:
            medias = [a.media_geral for a in avaliacoes if a.media_geral]
            media_geral = sum(medias) / len(medias) if medias else 0
            
            # Distribuição por classificação
            classificacoes = {}
            for a in avaliacoes:
                if a.classificacao:
                    classificacoes[a.classificacao] = classificacoes.get(a.classificacao, 0) + 1
        else:
            media_geral = 0
            classificacoes = {}
        
        # Top 5 funcionários por média
        top_funcionarios = db.session.query(
            Funcionario.nome,
            db.func.avg(Avaliacao.media_geral).label('media')
        ).join(Avaliacao).group_by(Funcionario.id).order_by(db.desc('media')).limit(5).all()
        
        return jsonify({
            'success': True,
            'data': {
                'estatisticas_gerais': {
                    'total_funcionarios': total_funcionarios,
                    'total_avaliacoes': total_avaliacoes,
                    'media_geral': round(media_geral, 2)
                },
                'distribuicao_classificacoes': classificacoes,
                'top_funcionarios': [{'nome': f.nome, 'media': round(f.media, 2)} for f in top_funcionarios]
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

