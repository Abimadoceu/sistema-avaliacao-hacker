from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from functools import wraps
from src.models.auth import db, Usuario, SessaoUsuario, create_admin_user

auth_bp = Blueprint('auth', __name__)

def token_required(f):
    """Decorator para rotas que requerem autenticação"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Verificar token no header Authorization
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer TOKEN
            except IndexError:
                return jsonify({'success': False, 'error': 'Token inválido'}), 401
        
        if not token:
            return jsonify({'success': False, 'error': 'Token de acesso necessário'}), 401
        
        try:
            current_user = Usuario.verify_token(token)
            if not current_user:
                return jsonify({'success': False, 'error': 'Token inválido ou expirado'}), 401
            
            # Verificar se a sessão ainda é válida
            sessao = SessaoUsuario.query.filter_by(token=token, ativo=True).first()
            if not sessao or not sessao.is_valid():
                return jsonify({'success': False, 'error': 'Sessão expirada'}), 401
            
        except Exception as e:
            return jsonify({'success': False, 'error': 'Token inválido'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

def admin_required(f):
    """Decorator para rotas que requerem privilégios de administrador"""
    @wraps(f)
    def decorated(current_user, *args, **kwargs):
        if not current_user.is_admin():
            return jsonify({'success': False, 'error': 'Acesso negado. Privilégios de administrador necessários.'}), 403
        return f(current_user, *args, **kwargs)
    
    return decorated

@auth_bp.route('/login', methods=['POST'])
def login():
    """Endpoint de login"""
    try:
        data = request.get_json()
        
        if not data or not data.get('email') or not data.get('senha'):
            return jsonify({'success': False, 'error': 'Email e senha são obrigatórios'}), 400
        
        usuario = Usuario.query.filter_by(email=data['email'], ativo=True).first()
        
        if not usuario or not usuario.check_password(data['senha']):
            return jsonify({'success': False, 'error': 'Email ou senha incorretos'}), 401
        
        # Gerar token
        token = usuario.generate_token()
        
        # Criar sessão
        sessao = SessaoUsuario(
            usuario_id=usuario.id,
            token=token,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent', ''),
            expires_at=datetime.utcnow() + timedelta(hours=24)
        )
        
        # Atualizar último login
        usuario.last_login = datetime.utcnow()
        
        db.session.add(sessao)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': {
                'token': token,
                'usuario': usuario.to_dict(),
                'expires_at': sessao.expires_at.isoformat()
            },
            'message': 'Login realizado com sucesso'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(current_user):
    """Endpoint de logout"""
    try:
        token = request.headers.get('Authorization').split(" ")[1]
        
        # Invalidar sessão
        sessao = SessaoUsuario.query.filter_by(token=token, ativo=True).first()
        if sessao:
            sessao.invalidate()
            db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Logout realizado com sucesso'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/me', methods=['GET'])
@token_required
def get_current_user(current_user):
    """Retorna informações do usuário atual"""
    return jsonify({
        'success': True,
        'data': current_user.to_dict()
    })

@auth_bp.route('/usuarios', methods=['GET'])
@token_required
@admin_required
def get_usuarios(current_user):
    """Lista todos os usuários (apenas admin)"""
    try:
        usuarios = Usuario.query.filter_by(ativo=True).order_by(Usuario.nome).all()
        return jsonify({
            'success': True,
            'data': [u.to_dict() for u in usuarios]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/usuarios', methods=['POST'])
@token_required
@admin_required
def create_usuario(current_user):
    """Cria novo usuário (apenas admin)"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['nome', 'email', 'senha', 'tipo']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se email já existe
        if Usuario.query.filter_by(email=data['email']).first():
            return jsonify({'success': False, 'error': 'Email já está em uso'}), 400
        
        # Validar tipo de usuário
        if data['tipo'] not in ['admin', 'avaliador']:
            return jsonify({'success': False, 'error': 'Tipo de usuário inválido'}), 400
        
        usuario = Usuario(
            nome=data['nome'],
            email=data['email'],
            tipo=data['tipo']
        )
        usuario.set_password(data['senha'])
        
        db.session.add(usuario)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': usuario.to_dict(),
            'message': 'Usuário criado com sucesso'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/usuarios/<int:usuario_id>', methods=['PUT'])
@token_required
@admin_required
def update_usuario(current_user, usuario_id):
    """Atualiza usuário (apenas admin)"""
    try:
        usuario = Usuario.query.get_or_404(usuario_id)
        data = request.get_json()
        
        # Atualizar campos permitidos
        if 'nome' in data:
            usuario.nome = data['nome']
        if 'email' in data:
            # Verificar se email já existe (exceto o próprio usuário)
            existing = Usuario.query.filter_by(email=data['email']).first()
            if existing and existing.id != usuario.id:
                return jsonify({'success': False, 'error': 'Email já está em uso'}), 400
            usuario.email = data['email']
        if 'tipo' in data:
            if data['tipo'] not in ['admin', 'avaliador']:
                return jsonify({'success': False, 'error': 'Tipo de usuário inválido'}), 400
            usuario.tipo = data['tipo']
        if 'senha' in data:
            usuario.set_password(data['senha'])
        if 'ativo' in data:
            usuario.ativo = data['ativo']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': usuario.to_dict(),
            'message': 'Usuário atualizado com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password(current_user):
    """Permite ao usuário alterar sua própria senha"""
    try:
        data = request.get_json()
        
        if not data.get('senha_atual') or not data.get('nova_senha'):
            return jsonify({'success': False, 'error': 'Senha atual e nova senha são obrigatórias'}), 400
        
        # Verificar senha atual
        if not current_user.check_password(data['senha_atual']):
            return jsonify({'success': False, 'error': 'Senha atual incorreta'}), 400
        
        # Definir nova senha
        current_user.set_password(data['nova_senha'])
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Senha alterada com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/sessoes', methods=['GET'])
@token_required
def get_sessoes(current_user):
    """Lista sessões ativas do usuário"""
    try:
        sessoes = SessaoUsuario.query.filter_by(
            usuario_id=current_user.id, 
            ativo=True
        ).order_by(SessaoUsuario.created_at.desc()).all()
        
        return jsonify({
            'success': True,
            'data': [s.to_dict() for s in sessoes]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@auth_bp.route('/init-admin', methods=['POST'])
def init_admin():
    """Inicializa usuário administrador (apenas se não existir)"""
    try:
        admin = create_admin_user()
        return jsonify({
            'success': True,
            'message': 'Usuário administrador inicializado',
            'data': {
                'email': 'admin@hackerindustrial.com',
                'senha': 'admin123'
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

