from flask import Blueprint, request, jsonify, session
from datetime import datetime
from functools import wraps
from models.models import db, CodigoAcesso

codigo_auth_bp = Blueprint('codigo_auth', __name__)

def codigo_required(f):
    """Decorator para verificar se o código de acesso é válido"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        codigo_str = session.get('codigo_acesso')
        
        if not codigo_str:
            return jsonify({'success': False, 'error': 'Código de acesso necessário'}), 401
        
        codigo = CodigoAcesso.query.filter_by(codigo=codigo_str, ativo=True).first()
        if not codigo:
            session.pop('codigo_acesso', None)
            return jsonify({'success': False, 'error': 'Código de acesso inválido'}), 401
        
        # Atualizar último acesso
        codigo.ultimo_acesso = datetime.utcnow()
        db.session.commit()
        
        return f(codigo, *args, **kwargs)
    return decorated_function

def gestor_required(f):
    """Decorator adicional para verificar se é gestor"""
    @wraps(f)
    def decorated_function(codigo, *args, **kwargs):
        if not codigo.is_gestor():
            return jsonify({'success': False, 'error': 'Acesso restrito a gestores'}), 403
        return f(codigo, *args, **kwargs)
    return decorated_function

@codigo_auth_bp.route('/verificar-codigo', methods=['POST'])
def verificar_codigo():
    """Verifica e autentica um código de acesso"""
    try:
        data = request.get_json()
        codigo_input = data.get('codigo', '').strip().upper()
        senha_input = data.get('senha', '').strip()
        
        if not codigo_input:
            return jsonify({'success': False, 'error': 'Código é obrigatório'}), 400
        
        # Buscar código no banco
        codigo = CodigoAcesso.query.filter_by(codigo=codigo_input, ativo=True).first()
        
        if not codigo:
            return jsonify({'success': False, 'error': 'Código de acesso inválido'}), 401
        
        # Verificar senha para gestores
        if codigo.is_gestor():
            if not senha_input:
                return jsonify({
                    'success': False, 
                    'error': 'Senha é obrigatória para gestores',
                    'requer_senha': True
                }), 400
            
            if not codigo.verificar_senha(senha_input):
                return jsonify({'success': False, 'error': 'Senha incorreta'}), 401
        
        # Salvar na sessão
        session['codigo_acesso'] = codigo.codigo
        
        # Atualizar último acesso
        codigo.ultimo_acesso = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Código verificado com sucesso',
            'data': codigo.to_dict()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@codigo_auth_bp.route('/verificar-tipo', methods=['POST'])
def verificar_tipo():
    """Verifica se um código requer senha (para gestores)"""
    try:
        data = request.get_json()
        codigo_input = data.get('codigo', '').strip().upper()
        
        if not codigo_input:
            return jsonify({'success': False, 'error': 'Código é obrigatório'}), 400
        
        # Buscar código no banco
        codigo = CodigoAcesso.query.filter_by(codigo=codigo_input, ativo=True).first()
        
        if not codigo:
            return jsonify({'success': False, 'error': 'Código de acesso inválido'}), 401
        
        return jsonify({
            'success': True,
            'data': {
                'codigo': codigo.codigo,
                'nome_usuario': codigo.nome_usuario,
                'tipo': codigo.tipo,
                'requer_senha': codigo.is_gestor()
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@codigo_auth_bp.route('/status', methods=['GET'])
def status():
    """Verifica o status de autenticação atual"""
    try:
        codigo_str = session.get('codigo_acesso')
        
        if not codigo_str:
            return jsonify({
                'success': True,
                'data': {'authenticated': False}
            })
        
        codigo = CodigoAcesso.query.filter_by(codigo=codigo_str, ativo=True).first()
        
        if not codigo:
            session.pop('codigo_acesso', None)
            return jsonify({
                'success': True,
                'data': {'authenticated': False}
            })
        
        return jsonify({
            'success': True,
            'data': {
                'authenticated': True,
                **codigo.to_dict()
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@codigo_auth_bp.route('/logout', methods=['POST'])
def logout():
    """Faz logout do usuário"""
    try:
        session.pop('codigo_acesso', None)
        return jsonify({
            'success': True,
            'message': 'Logout realizado com sucesso'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@codigo_auth_bp.route('/avaliadores', methods=['GET'])
@codigo_required
def listar_avaliadores(codigo):
    """Lista todos os avaliadores disponíveis"""
    try:
        avaliadores = CodigoAcesso.query.filter_by(tipo='avaliador', ativo=True).order_by(CodigoAcesso.codigo).all()
        return jsonify({
            'success': True,
            'data': [{'codigo': a.codigo, 'nome': a.nome_usuario} for a in avaliadores]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@codigo_auth_bp.route('/codigos', methods=['GET'])
@codigo_required
@gestor_required
def listar_codigos(codigo):
    """Lista todos os códigos de acesso (apenas gestores)"""
    try:
        codigos = CodigoAcesso.query.order_by(CodigoAcesso.tipo, CodigoAcesso.codigo).all()
        return jsonify({
            'success': True,
            'data': [c.to_dict() for c in codigos]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@codigo_auth_bp.route('/codigos', methods=['POST'])
@codigo_required
@gestor_required
def criar_codigo(codigo):
    """Cria um novo código de acesso (apenas gestores)"""
    try:
        data = request.get_json()
        
        required_fields = ['codigo', 'nome_usuario', 'tipo']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se código já existe
        existing = CodigoAcesso.query.filter_by(codigo=data['codigo'].upper()).first()
        if existing:
            return jsonify({'success': False, 'error': 'Código já existe'}), 400
        
        # Validar tipo
        if data['tipo'] not in ['gestor', 'avaliador']:
            return jsonify({'success': False, 'error': 'Tipo deve ser gestor ou avaliador'}), 400
        
        novo_codigo = CodigoAcesso(
            codigo=data['codigo'].upper(),
            nome_usuario=data['nome_usuario'],
            tipo=data['tipo']
        )
        
        # Definir senha se for gestor
        if data['tipo'] == 'gestor' and 'senha' in data:
            novo_codigo.definir_senha(data['senha'])
        
        db.session.add(novo_codigo)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': novo_codigo.to_dict(),
            'message': 'Código criado com sucesso'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

