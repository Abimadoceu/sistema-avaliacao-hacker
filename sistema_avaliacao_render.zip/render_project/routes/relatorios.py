from flask import Blueprint, request, jsonify, make_response
from datetime import datetime, date
from models.models import db, Funcionario, Avaliacao, CodigoAcesso
from routes.codigo_auth import codigo_required, gestor_required
from sqlalchemy import desc, or_
import json

relatorios_bp = Blueprint('relatorios', __name__)

@relatorios_bp.route('/relatorio-individual/<int:avaliacao_id>', methods=['GET'])
@codigo_required
def relatorio_individual(avaliacao_id):
    """Gerar relatório individual de uma avaliação"""
    try:
        # Buscar avaliação
        avaliacao = Avaliacao.query.get_or_404(avaliacao_id)
        
        # Verificar permissão
        codigo_acesso = CodigoAcesso.query.filter_by(codigo=request.headers.get('X-Codigo-Acesso')).first()
        if not codigo_acesso.can_access_avaliacao(avaliacao):
            return jsonify({'success': False, 'error': 'Acesso negado'}), 403
        
        # Buscar funcionário
        funcionario = Funcionario.query.get(avaliacao.funcionario_id)
        
        # Gerar HTML do relatório
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Relatório de Avaliação - {funcionario.nome}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; margin-bottom: 30px; }}
                .info-section {{ margin-bottom: 20px; }}
                .competencias {{ margin-bottom: 20px; }}
                .competencia {{ margin-bottom: 10px; }}
                .feedback {{ margin-top: 30px; }}
                table {{ width: 100%; border-collapse: collapse; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .nota {{ font-weight: bold; }}
                .classificacao {{ padding: 5px; border-radius: 3px; }}
                .excepcional {{ background-color: #d4edda; color: #155724; }}
                .acima {{ background-color: #cce5ff; color: #004085; }}
                .satisfatorio {{ background-color: #fff3cd; color: #856404; }}
                .abaixo {{ background-color: #f8d7da; color: #721c24; }}
                .insatisfatorio {{ background-color: #f5c6cb; color: #721c24; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>HACKER INDUSTRIAL</h1>
                <h2>Relatório de Avaliação de Desempenho</h2>
            </div>
            
            <div class="info-section">
                <h3>Informações Gerais</h3>
                <p><strong>Funcionário:</strong> {funcionario.nome}</p>
                <p><strong>Função:</strong> {funcionario.funcao}</p>
                <p><strong>Setor:</strong> {funcionario.setor}</p>
                <p><strong>Avaliador:</strong> {avaliacao.avaliador_nome}</p>
                <p><strong>Data da Avaliação:</strong> {avaliacao.data_avaliacao.strftime('%d/%m/%Y')}</p>
                <p><strong>Período Avaliado:</strong> {avaliacao.periodo_inicio.strftime('%d/%m/%Y')} a {avaliacao.periodo_fim.strftime('%d/%m/%Y')}</p>
            </div>
            
            <div class="competencias">
                <h3>Avaliação por Competências</h3>
                <table>
                    <tr>
                        <th>Competência</th>
                        <th>Nota</th>
                        <th>Descrição</th>
                    </tr>
                    <tr>
                        <td>Pontualidade e Disciplina</td>
                        <td class="nota">{avaliacao.pontualidade_disciplina}</td>
                        <td>{get_descricao_nota(avaliacao.pontualidade_disciplina)}</td>
                    </tr>
                    <tr>
                        <td>Iniciativa e Proatividade</td>
                        <td class="nota">{avaliacao.iniciativa_proatividade}</td>
                        <td>{get_descricao_nota(avaliacao.iniciativa_proatividade)}</td>
                    </tr>
                    <tr>
                        <td>Produtividade e Eficiência</td>
                        <td class="nota">{avaliacao.produtividade_eficiencia}</td>
                        <td>{get_descricao_nota(avaliacao.produtividade_eficiencia)}</td>
                    </tr>
                    <tr>
                        <td>Foco no Resultado</td>
                        <td class="nota">{avaliacao.foco_resultado}</td>
                        <td>{get_descricao_nota(avaliacao.foco_resultado)}</td>
                    </tr>
                    <tr>
                        <td>Cooperação e Trabalho em Equipe</td>
                        <td class="nota">{avaliacao.cooperacao_equipe}</td>
                        <td>{get_descricao_nota(avaliacao.cooperacao_equipe)}</td>
                    </tr>
                    <tr>
                        <td>Autorresponsabilidade</td>
                        <td class="nota">{avaliacao.autorresponsabilidade}</td>
                        <td>{get_descricao_nota(avaliacao.autorresponsabilidade)}</td>
                    </tr>
                    <tr>
                        <td>Dinamismo e Adaptabilidade</td>
                        <td class="nota">{avaliacao.dinamismo_adaptabilidade}</td>
                        <td>{get_descricao_nota(avaliacao.dinamismo_adaptabilidade)}</td>
                    </tr>
                    <tr>
                        <td>Liderança e Influência</td>
                        <td class="nota">{avaliacao.lideranca_influencia}</td>
                        <td>{get_descricao_nota(avaliacao.lideranca_influencia)}</td>
                    </tr>
                    <tr>
                        <td>Criatividade e Inovação</td>
                        <td class="nota">{avaliacao.criatividade_inovacao}</td>
                        <td>{get_descricao_nota(avaliacao.criatividade_inovacao)}</td>
                    </tr>
                    <tr>
                        <td>Conhecimento Técnico e Qualidade</td>
                        <td class="nota">{avaliacao.conhecimento_tecnico}</td>
                        <td>{get_descricao_nota(avaliacao.conhecimento_tecnico)}</td>
                    </tr>
                </table>
                
                <div style="margin-top: 20px;">
                    <p><strong>Média Geral:</strong> <span class="nota">{avaliacao.media}</span></p>
                    <p><strong>Classificação:</strong> 
                        <span class="classificacao {get_classe_classificacao(avaliacao.classificacao)}">{avaliacao.classificacao}</span>
                    </p>
                </div>
            </div>
            
            <div class="feedback">
                <h3>Comentários e Feedback</h3>
                
                {f'<div><h4>Pontos Fortes:</h4><p>{avaliacao.pontos_fortes}</p></div>' if avaliacao.pontos_fortes else ''}
                
                {f'<div><h4>Oportunidades de Melhoria:</h4><p>{avaliacao.oportunidades_melhoria}</p></div>' if avaliacao.oportunidades_melhoria else ''}
                
                {f'<div><h4>Metas de Desenvolvimento:</h4><p>{avaliacao.metas_desenvolvimento}</p></div>' if avaliacao.metas_desenvolvimento else ''}
                
                {f'<div><h4>Reconhecimentos:</h4><p>{avaliacao.reconhecimentos}</p></div>' if avaliacao.reconhecimentos else ''}
                
                {f'<div><h4>Autoavaliação:</h4><p>{avaliacao.autoavaliacao}</p></div>' if avaliacao.autoavaliacao else ''}
                
                {f'<div><h4>Feedback do Líder:</h4><p>{avaliacao.feedback_lider}</p><p><strong>Líder:</strong> {avaliacao.lider_nome}</p></div>' if avaliacao.feedback_lider else ''}
            </div>
            
            <div style="margin-top: 50px; text-align: center;">
                <p>Relatório gerado em {datetime.now().strftime('%d/%m/%Y às %H:%M')}</p>
            </div>
        </body>
        </html>
        """
        
        response = make_response(html_content)
        response.headers['Content-Type'] = 'text/html; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename="relatorio_{funcionario.nome}_{avaliacao.id}.html"'
        
        return response
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@relatorios_bp.route('/relatorio-completo', methods=['GET'])
@gestor_required
def relatorio_completo():
    """Gerar relatório completo com todas as avaliações"""
    try:
        # Filtros opcionais
        setor = request.args.get('setor')
        data_inicio = request.args.get('data_inicio')
        data_fim = request.args.get('data_fim')
        
        # Query base
        query = Avaliacao.query.join(Funcionario)
        
        # Aplicar filtros
        if setor:
            query = query.filter(Funcionario.setor == setor)
        if data_inicio:
            query = query.filter(Avaliacao.data_avaliacao >= datetime.strptime(data_inicio, '%Y-%m-%d').date())
        if data_fim:
            query = query.filter(Avaliacao.data_avaliacao <= datetime.strptime(data_fim, '%Y-%m-%d').date())
        
        avaliacoes = query.order_by(desc(Avaliacao.data_avaliacao)).all()
        
        # Calcular estatísticas
        total_avaliacoes = len(avaliacoes)
        media_geral = sum(a.media for a in avaliacoes) / total_avaliacoes if total_avaliacoes > 0 else 0
        
        # Gerar HTML do relatório completo
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Relatório Completo - HACKER INDUSTRIAL</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; margin-bottom: 30px; }}
                .stats {{ margin-bottom: 30px; }}
                .stat-item {{ display: inline-block; margin: 10px; padding: 15px; background: #f8f9fa; border-radius: 5px; }}
                table {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .classificacao {{ padding: 3px 8px; border-radius: 3px; font-size: 12px; }}
                .excepcional {{ background-color: #d4edda; color: #155724; }}
                .acima {{ background-color: #cce5ff; color: #004085; }}
                .satisfatorio {{ background-color: #fff3cd; color: #856404; }}
                .abaixo {{ background-color: #f8d7da; color: #721c24; }}
                .insatisfatorio {{ background-color: #f5c6cb; color: #721c24; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>HACKER INDUSTRIAL</h1>
                <h2>Relatório Completo de Avaliações</h2>
                <p>Período: {data_inicio or 'Início'} a {data_fim or 'Atual'}</p>
                {f'<p>Setor: {setor}</p>' if setor else ''}
            </div>
            
            <div class="stats">
                <div class="stat-item">
                    <h3>{total_avaliacoes}</h3>
                    <p>Total de Avaliações</p>
                </div>
                <div class="stat-item">
                    <h3>{media_geral:.2f}</h3>
                    <p>Média Geral</p>
                </div>
                <div class="stat-item">
                    <h3>{len(set(a.funcionario.setor for a in avaliacoes))}</h3>
                    <p>Setores Avaliados</p>
                </div>
            </div>
            
            <table>
                <tr>
                    <th>Funcionário</th>
                    <th>Função</th>
                    <th>Setor</th>
                    <th>Avaliador</th>
                    <th>Data</th>
                    <th>Média</th>
                    <th>Classificação</th>
                </tr>
        """
        
        for avaliacao in avaliacoes:
            funcionario = avaliacao.funcionario
            html_content += f"""
                <tr>
                    <td>{funcionario.nome}</td>
                    <td>{funcionario.funcao}</td>
                    <td>{funcionario.setor}</td>
                    <td>{avaliacao.avaliador_nome}</td>
                    <td>{avaliacao.data_avaliacao.strftime('%d/%m/%Y')}</td>
                    <td>{avaliacao.media}</td>
                    <td><span class="classificacao {get_classe_classificacao(avaliacao.classificacao)}">{avaliacao.classificacao}</span></td>
                </tr>
            """
        
        html_content += f"""
            </table>
            
            <div style="margin-top: 50px; text-align: center;">
                <p>Relatório gerado em {datetime.now().strftime('%d/%m/%Y às %H:%M')}</p>
            </div>
        </body>
        </html>
        """
        
        response = make_response(html_content)
        response.headers['Content-Type'] = 'text/html; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename="relatorio_completo_{datetime.now().strftime("%Y%m%d")}.html"'
        
        return response
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def get_descricao_nota(nota):
    """Retorna descrição da nota"""
    descricoes = {
        1: "Insatisfatório - Não atende às expectativas",
        2: "Abaixo do Esperado - Atende parcialmente",
        3: "Satisfatório - Atende às expectativas",
        4: "Acima do Esperado - Supera expectativas",
        5: "Excepcional - Performance exemplar"
    }
    return descricoes.get(nota, "Não avaliado")

def get_classe_classificacao(classificacao):
    """Retorna classe CSS para classificação"""
    classes = {
        'Excepcional': 'excepcional',
        'Acima do Esperado': 'acima',
        'Satisfatório': 'satisfatorio',
        'Abaixo do Esperado': 'abaixo',
        'Insatisfatório': 'insatisfatorio'
    }
    return classes.get(classificacao, '')

